**To delete an API**

Command::

  aws apigateway delete-rest-api --rest-api-id 1234123412
